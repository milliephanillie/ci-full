<?php


namespace Lisfinity\Models\Users;


class UserModel {

}
