<?php
/**
 * Template Name: Page | Terms
 * Description: Page template that is being used for site terms and privacy policy.
 *
 * @author pebas
 * @package templates/pages
 * @version 1.0.0
 */
?>

<?php include get_parent_theme_file_path( 'page.php' ); ?>
