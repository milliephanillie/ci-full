<?php
/**
 * Template Name: Shortcodes | Product Sidebar Menu
 * Description: The file that is being used to display product sidebar menu shortcode
 *
 * @author pebas
 * @package templates/shortcodes/single
 * @version 1.0.0
 *
 * @var $args
 */

?>
<div class="elementor-product-sidebar-menu"></div>
